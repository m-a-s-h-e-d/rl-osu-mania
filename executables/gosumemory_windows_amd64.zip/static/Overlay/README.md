# How to use

### Font 
To set custom font you need to add font file to resources folder and change src url in index.css file to your font.
All elements in index.css file have property font-size amount of pixels can be modified as you want.

### Score bar
To change Score bar image you need to add scorebar-bg and scorebar-colour to resource folder and set them in index.html,
also you need to specified width property of your scorebar-colour in index.css in sbColor element.

### Position
all elements positioned absolutely in 1920 x 1080 area in index.css you can find properties: top left right and bottom 
For example left: 0 and bottom: 0 will position element to the left bottom corner 
